'use client';
import Link from 'next/link';
import { useUser, useSupabaseClient } from '@supabase/auth-helpers-react';

export default function Header() {
    const user = useUser();
    const supabase = useSupabaseClient();

    const handleLogout = async () => {
        await supabase.auth.signOut();
        window.location.href = '/login';
    };

    return (
        <nav className="p-4 bg-gray-800 text-white">
            <ul className="flex space-x-4">
                <li><Link href="/">Home</Link></li>
                <li><Link href="/gallery">Gallery</Link></li>
                <li><Link href="/pricing">Pricing</Link></li>
                {user && <li><Link href="/dashboard">Dashboard</Link></li>}
                {user ? (
                    <li><button onClick={handleLogout}>Logout</button></li>
                ) : (
                    <li><Link href="/login">Login</Link></li>
                )}
            </ul>
        </nav>
    );
}