import GalleryClient from '../../components/GalleryClient';
import Header from '../../components/Header';
import AuthProvider from '../../components/AuthProvider';
import { createServerSupabaseClient } from '@/utils/supabase/server';

export default async function Gallery() {
    const supabase = createServerSupabaseClient();
    const { data: components } = await supabase.from('components').select('*');

    return (
        <AuthProvider>
            <Header />
            <GalleryClient components={components || []} />
        </AuthProvider>
    );
}