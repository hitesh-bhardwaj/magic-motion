import { createClient } from '@supabase/supabase-js';
import { serialize } from 'next-mdx-remote/serialize';
import fs from 'fs';
import path from 'path';
import AuthProvider from '../../../components/AuthProvider';
import ComponentPageClient from '../../../components/ComponentPageClient';

// ---- STATIC PARAMS: build-time, NO cookies()! ----
export async function generateStaticParams() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  );
  const { data } = await supabase.from('components').select('slug');
  return data?.map(({ slug }) => ({ slug })) ?? [];
}

// ---- PAGE: server component during a request, OK to use cookies() ----
import { createServerSupabaseClient } from '@/utils/supabase/server';

export default async function ComponentPage({ params }) {
  const supabase = createServerSupabaseClient(); 
  const { data: component, error } = await supabase
    .from('components')
    .select('*')
    .eq('slug', params.slug)
    .single();

  if (error || !component) {
    return <div>Error: Component not found</div>;
  }

  const mdxPath = path.join(process.cwd(), 'components', `${params.slug}.mdx`);
  let mdx;
  try {
    mdx = await serialize(fs.readFileSync(mdxPath, 'utf8'));
  } catch {
    return <div>Error: MDX file not found</div>;
  }

  return (
    <AuthProvider>
      <ComponentPageClient component={component} mdx={mdx} />
    </AuthProvider>
  );
}
