import DashboardClient from '../../components/DashboardClient';
import AuthProvider from '../../components/AuthProvider';
import Header from '../../components/Header';
import { createServerSupabaseClient } from '@/utils/supabase/server';

export default async function Dashboard() {
  const supabase = createServerSupabaseClient();
  const { data: components } = await supabase.from('components').select('*');

  return (
    <AuthProvider>
      <Header />
      <DashboardClient components={components || []} />
    </AuthProvider>
  );
}