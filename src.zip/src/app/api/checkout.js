import Stripe from 'stripe';
import { createServerSupabaseClient } from '@supabase/auth-helpers-nextjs';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
    const supabase = createServerSupabaseClient({ req, res });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    const { mode, componentId } = req.body;
    let priceId;
    if (mode === 'subscription') {
        priceId = process.env.STRIPE_SUBSCRIPTION_PRICE_ID; // e.g., price_xxx
    } else if (mode === 'one_time') {
        priceId = process.env[`STRIPE_COMPONENT_${componentId}_PRICE_ID`]; // e.g., price_yyy
    }

    const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [{ price: priceId, quantity: 1 }],
        mode: mode === 'subscription' ? 'subscription' : 'payment',
        success_url: `${process.env.NEXT_PUBLIC_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.NEXT_PUBLIC_URL}/pricing`,
        metadata: { userId: user.id, componentId: mode === 'one_time' ? componentId : null },
    });

    res.json({ sessionId: session.id });
}