import Stripe from 'stripe';
import { supabase } from '../../lib/supabase';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
    const sig = req.headers['stripe-signature'];
    let event;

    try {
        event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
    } catch (err) {
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === 'checkout.session.completed') {
        const session = event.data.object;
        const userId = session.metadata.userId;
        const mode = session.mode;

        if (mode === 'subscription') {
            await supabase.from('subscriptions').upsert({
                user_id: userId,
                stripe_subscription_id: session.subscription,
                status: 'active',
            });
        } else if (mode === 'payment') {
            await supabase.from('entitlements').insert({
                user_id: userId,
                component_id: session.metadata.componentId,
            });
        }
    } else if (event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.deleted') {
        const subscription = event.data.object;
        await supabase.from('subscriptions').update({ status: subscription.status }).eq('stripe_subscription_id', subscription.id);
    }

    res.status(200).end();
}

export const config = { api: { bodyParser: { raw: { type: 'application/json' } } } };