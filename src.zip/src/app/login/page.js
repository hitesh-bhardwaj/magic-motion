'use client'

import { useState } from 'react';
     import { useSupabaseClient } from '@supabase/auth-helpers-react';
     import Header from '../../components/Header';

     export default function Login() {
       const [email, setEmail] = useState('');
       const [password, setPassword] = useState('');
       const supabase = useSupabaseClient();

       const handleLogin = async () => {
         const { error } = await supabase.auth.signInWithPassword({ email, password });
         if (!error) window.location.href = '/dashboard';
         else alert(error.message);
       };

       return (
         <div>
           <Header />
           <div className="p-4 max-w-md mx-auto">
             <h1 className="text-2xl">Login</h1>
             <input
               type="email"
               value={email}
               onChange={e => setEmail(e.target.value)}
               placeholder="Email"
               className="border p-2 w-full mb-2"
             />
             <input
               type="password"
               value={password}
               onChange={e => setPassword(e.target.value)}
               placeholder="Password"
               className="border p-2 w-full mb-2"
             />
             <button onClick={handleLogin} className="bg-blue-500 text-white p-2 w-full">Login</button>
             <p>Don’t have an account? <a href="/signup" className="text-blue-500">Sign up</a></p>
           </div>
         </div>
       );
     }