'use client'
import { useState } from 'react';
import { useSupabaseClient } from '@supabase/auth-helpers-react';
import Header from '../../components/Header';

export default function Signup() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const supabase = useSupabaseClient();

    const handleSignup = async () => {
        const { error } = await supabase.auth.signUp({ email, password });
        if (!error) window.location.href = '/dashboard';
        else alert(error.message);
    };

    return (
        <div>
            <Header />
            <div className="p-4 max-w-md mx-auto">
                <h1 className="text-2xl">Sign Up</h1>
                <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="Email"
                    className="border p-2 w-full mb-2"
                />
                <input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Password"
                    className="border p-2 w-full mb-2"
                />
                <button onClick={handleSignup} className="bg-blue-500 text-white p-2 w-full">Sign Up</button>
                <p>Already have an account? <a href="/login" className="text-blue-500">Login</a></p>
            </div>
        </div>
    );
}