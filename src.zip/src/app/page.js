import Header from '../components/Header';

export default function Home() {
  return (
    <div>
      <Header />
      <div className="p-4">
        <h1 className="text-2xl">Welcome to GSAP Components</h1>
        <p>Browse our collection of free and paid GSAP components.</p>
      </div>
    </div>
  );
}