'use client'
import { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { useUser, useSupabaseClient } from '@supabase/auth-helpers-react';
import Header from '@/components/Header';

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY);

export default function Pricing() {
  const [components, setComponents] = useState([]);
  const user = useUser();
  const supabase = useSupabaseClient();

  useEffect(() => {
    const fetchComponents = async () => {
      const { data } = await supabase.from('components').select('*').eq('status', 'paid');
      setComponents(data || []);
    };
    fetchComponents();
  }, [supabase]);

  const handleCheckout = async (mode, componentId) => {
    if (!user) {
      window.location.href = '/login';
      return;
    }
    const stripe = await stripePromise;
    const response = await fetch('/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode, componentId }),
    });
    const { sessionId } = await response.json();
    await stripe.redirectToCheckout({ sessionId });
  };

  return (
    <div>
      <Header />
      <div className="p-4">
        <h1 className="text-2xl">Pricing</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="border p-4">
            <h2 className="text-xl">Subscription</h2>
            <p>Unlock all components for $5/month.</p>
            <button
              onClick={() => handleCheckout('subscription')}
              className="bg-blue-500 text-white p-2 mt-2"
            >
              Subscribe
            </button>
          </div>
          {components.map(component => (
            <div key={component.id} className="border p-4">
              <h2 className="text-xl">{component.title}</h2>
              <p>{component.description}</p>
              <p>$10 one-time</p>
              <button
                onClick={() => handleCheckout('one_time', component.id)}
                className="bg-blue-500 text-white p-2 mt-2"
              >
                Buy Now
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}